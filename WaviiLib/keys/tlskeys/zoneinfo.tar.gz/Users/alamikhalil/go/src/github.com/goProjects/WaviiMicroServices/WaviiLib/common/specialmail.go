package common

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"html/template"

	"gopkg.in/gomail.v2"
)

// SendSpecialEmail :  sending a mail with more than just one button
func SendSpecialEmail(from, to, subject, name, email, token, linkbegin, linkbegin2, htmlfile string) {

	url := SpecialURLData{
		Email: email,
		Key:   token,
	}

	jsondata, err := json.Marshal(url)
	if err != nil {
		return
	}
	encoded := base64.StdEncoding.EncodeToString([]byte(jsondata))

	urltosend := linkbegin + encoded
	urltosend2 := linkbegin2 + encoded

	templateData := SpecialTempl{
		Name: name,
		URL:  urltosend,
		URL2: urltosend2,
	}

	r := NewSpecialRequest([]string{from}, subject, "Email Verification")
	r.ParseSpecialTemplate(htmlfile, templateData)

	m := gomail.NewMessage()

	m.SetHeader("From", from)
	m.SetHeader("To", to)
	m.SetHeader("Subject", r.Subject)
	m.SetBody("text/html", r.Body)

	d := gomail.NewPlainDialer("smtp.gmail.com", 587, AppConfig.EmailAddress, AppConfig.EmailPassword)

	if err := d.DialAndSend(m); err != nil {
		panic(err)
	}
}

type (
	//SpecialRequest Strcut
	SpecialRequest struct {
		From    string   `json:"from"`
		To      []string `json:"to"`
		Subject string   `json:"subject"`
		Body    string   `json:"body"`
	}

	//SpecialURLData : Used to hash the data and create the link to be sent...
	SpecialURLData struct {
		Email string `json:"email"`
		Key   string `json:"key"`
	}

	//SpecialTempl : Name of the person to add to the template and the url for verification
	SpecialTempl struct {
		Name string `json:"name"`
		URL  string `json:"url"`
		URL2 string `json:"url2"`
	}
)

// NewSpecialRequest :
func NewSpecialRequest(to []string, subject, body string) *Request {
	return &Request{
		To:      to,
		Subject: subject,
		Body:    body,
	}
}

// ParseSpecialTemplate :
func (r *Request) ParseSpecialTemplate(templateFileName string, data interface{}) error {
	t, err := template.ParseFiles(templateFileName)
	if err != nil {
		return err
	}
	buf := new(bytes.Buffer)
	if err = t.Execute(buf, data); err != nil {
		return err
	}
	r.Body = buf.String()
	return nil
}
