package common

import (
	"log"
	"time"

	"gopkg.in/mgo.v2"
)

/*
** microServices can be created by just putting every db models, collections, and related methods in its own server....**


Contains methods for:
	- creating sessions for mongoDb.
	- getting the current session.
	- adding secondary indices for performance improvements.


In this file:
	-five different different databases:
		- userAuth: storing users authentication data.
		- userStats: storing user stats, recommendations and history, ""and other future statistic related data.
		- userProfiles: storing users profile "sex, weight, name...", and other small dbs.
		- staticContent: storing relatively static content like blog articles, exercises....
		- adminDb : contains admin auth and other admin related data.


Possible refactoring:
	- creating a function for session creation. **
	- creating a function for index initialization. **
	- creating a method for ensuring. **
*/

// a mongoDB session
var session *mgo.Session

// GetSession : method that returns current session otherwise creates a new session and return it
func GetSession() *mgo.Session {
	if session == nil {
		var err error

		session, err = mgo.DialWithInfo(&mgo.DialInfo{
			Addrs:    []string{AppConfig.MongoDBHost}, // in config.json link to mongodb
			Username: AppConfig.DBUser,                // username for accessing the db
			Password: AppConfig.DBPwd,                 // password for accessing the db
			Timeout:  60 * time.Second,                // returns an error if request takes more than 60sex
		})

		if err != nil {
			log.Fatalf("[GetSession2]: %s\n", err)
		}
	}

	return session
}

// method for creating a new session
func createDbSession() {
	var err error

	session, err = mgo.DialWithInfo(&mgo.DialInfo{
		Addrs:    []string{AppConfig.MongoDBHost},
		Username: AppConfig.DBUser,
		Password: AppConfig.DBPwd,
		Timeout:  60 * time.Second,
	})

	if err != nil {
		log.Fatalf("[createDbSession]: %s\n", err)
	}

}

// Add Indexes into MongoDB to increase Performance,
func addIndexes() {
	var err error

	// User Auth Secondary indices
	userAuthIndex := mgo.Index{
		Key:        []string{"email"},
		Unique:     true,
		DropDups:   true,
		Background: true,
		Sparse:     true,
	}

	// Admin Auth Secondary indices
	adminAuthIndex := mgo.Index{
		Key:        []string{"email"},
		Unique:     true,
		DropDups:   true,
		Background: true,
		Sparse:     true,
	}

	// User Profile Secondary indices
	userProfilesIndex := mgo.Index{
		Key:        []string{"firstname", "_id"},
		Unique:     false,
		DropDups:   true,
		Background: true,
		Sparse:     true,
	}

	// User stats Secondary index
	userStatsIndex := mgo.Index{
		Key:        []string{"deviceid", "_id"},
		Unique:     true,
		DropDups:   true,
		Background: true,
		Sparse:     true,
	}

	// Exercise Secondary index
	exercisesIndex := mgo.Index{
		Key:        []string{"exercisename"},
		Unique:     true,
		DropDups:   true,
		Background: true,
		Sparse:     true,
	}

	// Blog Secondary index
	blogArticlesIndex := mgo.Index{
		Key:        []string{"blogtitle"},
		Unique:     true,
		DropDups:   true,
		Background: true,
		Sparse:     true,
	}

	// Blog Secondary index
	pushEventsIndex := mgo.Index{
		Key:        []string{"eventtitle"},
		Unique:     true,
		DropDups:   true,
		Background: true,
		Sparse:     true,
	}

	// VersionCheck Secondary index
	versionCheckIndex := mgo.Index{
		Key:        []string{"globalappversionname"},
		Unique:     true,
		DropDups:   true,
		Background: true,
		Sparse:     true,
	}

	tagsIndex := mgo.Index{
		Key:        []string{"name"},
		Unique:     true,
		DropDups:   true,
		Background: true,
		Sparse:     true,
	}

	pathologiesIndex := mgo.Index{
		Key:        []string{"name"},
		Unique:     true,
		DropDups:   true,
		Background: true,
		Sparse:     true,
	}

	riskyMovementsIndex := mgo.Index{
		Key:        []string{"name"},
		Unique:     true,
		DropDups:   true,
		Background: true,
		Sparse:     true,
	}

	waviiIdsIndex := mgo.Index{
		Key:        []string{"ownedby"},
		Unique:     true,
		DropDups:   true,
		Background: true,
		Sparse:     true,
	}

	posturesIndex := mgo.Index{
		Key:        []string{"posturename"},
		Unique:     true,
		DropDups:   true,
		Background: true,
		Sparse:     true,
	}

	supportIndex := mgo.Index{
		Key:        []string{"answeredby"},
		Unique:     false,
		DropDups:   false,
		Background: true,
		Sparse:     true,
	}

	mailingIndex := mgo.Index{
		Key:        []string{"subject"},
		Unique:     false,
		DropDups:   false,
		Background: true,
		Sparse:     true,
	}

	// Add indexes into MongoDB
	sess := GetSession().Copy()
	defer sess.Close()

	// ensure index for userauth collection
	userAuthCol := sess.DB(AppConfig.Database).C("usersauth")
	err = userAuthCol.EnsureIndex(userAuthIndex)
	if err != nil {
		log.Fatalf("[addIndexes]: %s\n", err)
	}

	// ensure index for userauth collection
	adminAuthCol := sess.DB(AppConfig.DatabaseAdmin).C("adminauth")
	err = adminAuthCol.EnsureIndex(adminAuthIndex)
	if err != nil {
		log.Fatalf("[addIndexes]: %s\n", err)
	}

	// ensure index for userProfile collection
	userProfileCol := sess.DB(AppConfig.DatabaseUser).C("usersprofile")
	err = userProfileCol.EnsureIndex(userProfilesIndex)
	if err != nil {
		log.Fatalf("[addIndexes]; %s\n", err)
	}

	// ensure index for userStats collection
	userStatsCol := sess.DB(AppConfig.DatabaseStats).C("userstats")
	err = userStatsCol.EnsureIndex(userStatsIndex)
	if err != nil {
		log.Fatalf("[addIndexes]; %s\n", err)
	}

	// ensure index for exercise collection
	exerciseCol := sess.DB(AppConfig.DatabaseStatic).C("exercises")
	err = exerciseCol.EnsureIndex(exercisesIndex)
	if err != nil {
		log.Fatalf("[addIndexes]; %s\n", err)
	}

	// ensure index for blog collection
	blogCol := sess.DB(AppConfig.DatabaseStatic).C("blogarticles")
	err = blogCol.EnsureIndex(blogArticlesIndex)
	if err != nil {
		log.Fatalf("[addIndexes]; %s\n", err)
	}

	// ensure index for push events collection
	pushEventCol := sess.DB(AppConfig.DatabaseAdmin).C("pushevents")
	err = pushEventCol.EnsureIndex(pushEventsIndex)
	if err != nil {
		log.Fatalf("[addIndexes]; %s\n", err)
	}

	// ensure index for push events collection
	versionCol := sess.DB(AppConfig.DatabaseStatic).C("versioncheck")
	err = versionCol.EnsureIndex(versionCheckIndex)
	if err != nil {
		log.Fatalf("[addIndexes]; %s\n", err)
	}

	// ensure index for tag collection
	tagCol := sess.DB(AppConfig.DatabaseStatic).C("tags")
	err = tagCol.EnsureIndex(tagsIndex)
	if err != nil {
		log.Fatalf("[addIndexes]; %s\n", err)
	}

	// ensure index for pathologies collection
	pathologyCol := sess.DB(AppConfig.DatabaseStatic).C("pathologies")
	err = pathologyCol.EnsureIndex(pathologiesIndex)
	if err != nil {
		log.Fatalf("[addIndexes]; %s\n", err)
	}

	// ensure index for riskymovements collection
	riskyMovementCol := sess.DB(AppConfig.DatabaseStatic).C("riskymovements")
	err = riskyMovementCol.EnsureIndex(riskyMovementsIndex)
	if err != nil {
		log.Fatalf("[addIndexes]; %s\n", err)
	}

	// ensure index for waviiids collection
	waviiIdsCol := sess.DB(AppConfig.DatabaseStatic).C("waviiids")
	err = waviiIdsCol.EnsureIndex(waviiIdsIndex)
	if err != nil {
		log.Fatalf("[addIndexes]; %s\n", err)
	}

	// ensure index for postures collection
	posturesCol := sess.DB(AppConfig.DatabaseStatic).C("postures")
	err = posturesCol.EnsureIndex(posturesIndex)
	if err != nil {
		log.Fatalf("[addIndexes]; %s\n", err)
	}

	// ensure index for tag collection
	supportCol := sess.DB(AppConfig.DatabaseAdmin).C("support")
	err = supportCol.EnsureIndex(supportIndex)
	if err != nil {
		log.Fatalf("[addIndexes]; %s\n", err)
	}

	// ensure index for tag collection
	mailingCol := sess.DB(AppConfig.DatabaseAdmin).C("mailing")
	err = mailingCol.EnsureIndex(mailingIndex)
	if err != nil {
		log.Fatalf("[addIndexes]; %s\n", err)
	}
}
