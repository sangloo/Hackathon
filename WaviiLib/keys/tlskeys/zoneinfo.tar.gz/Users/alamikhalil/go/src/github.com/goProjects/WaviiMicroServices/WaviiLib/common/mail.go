package common

import (
	"bytes"
	"crypto/tls"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"html/template"
	"log"

	"gopkg.in/gomail.v2"
)

// SendEmail :  Basic function for sending a message with one button
func SendEmail(from string, to string, subject string, name string, email string, token string, linkbegin string, htmlfile string) {

	url := URLData{
		Email: email,
		Key:   token,
	}

	jsondata, err := json.Marshal(url)
	if err != nil {
		fmt.Println("error marshallin json: ", err)
		return
	}
	encoded := base64.StdEncoding.EncodeToString([]byte(jsondata))

	urltosend := linkbegin + encoded

	templateData := Templ{
		Name: name,
		URL:  urltosend,
	}

	r := NewRequest([]string{from}, subject, "Email Verification")
	r.ParseTemplate(htmlfile, templateData)

	m := gomail.NewMessage()

	m.SetHeader("From", from)
	m.SetHeader("To", to)
	m.SetHeader("Subject", r.Subject)
	m.SetBody("text/html", r.Body)

	cert, err := tls.LoadX509KeyPair("WaviiLib/keys/tlskeys/server.pem", "WaviiLib/keys/tlskeys/server.key")
	if err != nil {
		log.Println(err)
		return
	}

	d := gomail.NewPlainDialer("smtp.gmail.com", 587, AppConfig.EmailAddress, AppConfig.EmailPassword)
	d.TLSConfig = &tls.Config{Certificates: []tls.Certificate{cert}, ServerName: "smtp.gmail.com"}

	if err := d.DialAndSend(m); err != nil {
		fmt.Println("error sending the message: ", err)
		return
	}

}

type (
	//Request Strcut
	Request struct {
		From    string
		To      []string
		Subject string
		Body    string
	}

	// URLData Used to hash the data and create the link to be sent...
	URLData struct {
		Email string `json:"email"`
		Key   string `json:"key"`
	}

	// Templ Name of the person to add to the template and the url for verification
	Templ struct {
		Name string `json:"name"`
		URL  string `json:"url"`
	}
)

// NewRequest : sending a new request
func NewRequest(to []string, subject, body string) *Request {
	return &Request{
		To:      to,
		Subject: subject,
		Body:    body,
	}
}

// ParseTemplate :
func (r *Request) ParseTemplate(templateFileName string, data interface{}) error {
	t, err := template.ParseFiles(templateFileName)
	if err != nil {
		fmt.Println("error parsing the files: ", err)
		return err
	}
	buf := new(bytes.Buffer)
	if err = t.Execute(buf, data); err != nil {
		fmt.Println("error in the buffer: ", err)
		return err
	}
	r.Body = buf.String()
	return nil
}
